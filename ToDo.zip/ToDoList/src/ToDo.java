import java.util.ArrayList;
import java.io.*;
public class ToDo {
	
	int num_progetti;
	String[] elenco_progetti;
	static String DIRECTORY_PROGETTI = "./progetti/";
	static int numMaxProgetti = 16;
	
	public ToDo() throws IOException {
		this.num_progetti=0;
		getProgetti();
	}
	
	void getProgetti() {
		File f  = new File(this.DIRECTORY_PROGETTI);
		String[] arrc = f.list();
		if(arrc.length != 0) {
			this.elenco_progetti = new String[arrc.length];
			for(int i=0; i<this.elenco_progetti.length;i++) {
				this.elenco_progetti[i] = arrc[i];
			}
			//System.arraycopy(arrc, 0, this.elenco_progetti,0,arrc.length);
			this.num_progetti  = this.elenco_progetti.length;
		} else {
			this.num_progetti = 0;
		}
		
	}
	
	public String elencaProgetti() {
		String st="";
		for(int i=0;i<this.elenco_progetti.length;i++) {
			st+=this.elenco_progetti[i];
		}
		return st;
	}
	
	public String getProgettoIndx(int i) {
		String s = this.elenco_progetti[i];
		return s;
	}
	
	public Progetto selezionaProgetto(String den) throws IOException{
		Progetto Prog = new Progetto(den);		
		return Prog;
	}
	
	public Progetto creaProgetto(String den) throws IOException{
		if(this.num_progetti < 16) {
			Progetto Prog = new Progetto(den);
			getProgetti();
			return Prog;
		}
		return null;
	}

	public void eliminaProgetto(String den) throws IOException{
			File f = new File(this.DIRECTORY_PROGETTI+den);
			f.delete();
			getProgetti();			
	}
}
