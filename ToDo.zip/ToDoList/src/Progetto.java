import java.util.GregorianCalendar;
import java.io.*;
import java.util.*;

public class Progetto {
	
	static String DIRECTORY_PROGETTI = "./progetti/";
	static String PROGETTO_PREDEFINITO = "./progetti/progetto";
	String denominazione;
	Attivit�[] attivit� = new Attivit�[64];
	int num_attivit�;
	
	FileReader fr;
	BufferedReader br;
	FileWriter fw;
	
	
	public Progetto(String d) throws IOException{
		this.denominazione=d;
		this.num_attivit�=0;
		try {
			File f = new File(this.DIRECTORY_PROGETTI+d);	//apro stream sul file del progetto
			//controllo se il progetto esiste in memoria
			if(f.exists()) {	
				fr = new FileReader(this.DIRECTORY_PROGETTI+this.denominazione);
				br = new BufferedReader(fr);
				fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione,true);	//imposto la scrittura su file in append
				leggiProgetto();
			} else {	//se il progetto non esiste lo creo nella directory progetti
				f.getParentFile().mkdirs();
				f.createNewFile();
			}
		} catch (IOException e) {	//se la creazione d� errore creo un file di "base"
			File f = new File(this.PROGETTO_PREDEFINITO);
			f.getParentFile().mkdirs();
			f.createNewFile();
			fr = new FileReader(this.PROGETTO_PREDEFINITO);
			br = new BufferedReader(fr);
			fw = new FileWriter(this.PROGETTO_PREDEFINITO,true);	//imposto la scrittura su file in append
			
		}
	}
	
	//inizializza i parametri delle attivit� nel progetto 
	void leggiProgetto() throws IOException {
		int i=0;
		while(i<64 && br.readLine()!=null) {
			this.attivit�[i].setDescrizione(br.readLine());
			GregorianCalendar ds = new GregorianCalendar();		//data scadenza
			GregorianCalendar dc = new GregorianCalendar();;	//data completamento
			ds.setTimeInMillis(Long.parseLong(br.readLine()));
			dc.setTimeInMillis(Long.parseLong(br.readLine()));
			this.attivit�[i].setScadenza(ds);			
			this.attivit�[i].setCompletamento(dc);
			this.attivit�[i].setSvolgimento(Integer.parseInt(br.readLine()),dc);
			br.readLine();	//salto la riga di separazione
			i++;
		}
	}
	
	public String getDenominazione() {return this.denominazione;}
	
	public boolean creaAttivit�(String den, GregorianCalendar data_scad) throws IOException{
		Attivit� newAttivit� = new Attivit�(den,data_scad);
	
		//scrivo in append sul file la nuova attivit�
		if (this.num_attivit� < 64) {	//controllo se il numMax attivt� � stato superato
			fw.write(newAttivit�.getDescrizione());
			fw.write(""+newAttivit�.getScadenza().getTimeInMillis());
			fw.write(""+newAttivit�.getCompletamento().getTimeInMillis());
			fw.write(""+newAttivit�.getSvolgimento());
			fw.write("");
			this.num_attivit�++;
			for(int i=0;i<64;i++) {	//aggiungo l'attivit� alla lista
				if(this.attivit�[i]==null) {
					this.attivit�[i] = new Attivit�(newAttivit�);
				}
			}
		} else {return false;}	
		
		return true;	//aggiunta attivit� con successo
	}
	
	public boolean eliminaAttivit�(String den) throws IOException{
		this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione);
		
		//rimuovo l'attivit� dalla lista di attivit�
		for(int i=0;i<64;i++) {
			if(this.attivit�[i].getDescrizione().equals(den)) {
				this.attivit�[i] = null;
				break;
			}
		}
		
		if(this.num_attivit� != 0) {	//riscrivo il file in modo da eliminare l'attivit�
			for(int i=0; i<64; i++) {
				if(this.attivit�[i]!=null) {
					fw.write(this.attivit�[i].getDescrizione());
					fw.write(""+this.attivit�[i].getScadenza().getTimeInMillis());
					fw.write(""+this.attivit�[i].getCompletamento().getTimeInMillis());
					fw.write(""+this.attivit�[i].getSvolgimento());					
					fw.write("");
				}
			}
			this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione,true);
			return true;
		}
		
		return false;
	}
	
	//modifico l'attivit�, ma non la sua descrizione
	public boolean aggiornaAttivit�(String den,int svolg, GregorianCalendar data_Scad) throws IOException {
		this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione);
		//controllo che l'attivit� esista
		boolean ck=false;
		GregorianCalendar td = new GregorianCalendar();
		for(int i=0;i<64;i++) {
			if(this.attivit�[i].getDescrizione().equals(den)) {
				this.attivit�[i].setSvolgimento(svolg,data_Scad);
				this.attivit�[i].setDescrizione(den);
				this.attivit�[i].setCompletamento(td);
				ck=true;
			}
		}
		
		if(ck == true) {
			//riscrivo il file con le informazioni aggiornate
			for(int i=0;i<64;i++) {
				fw.write(this.attivit�[i].getDescrizione());
				fw.write(""+this.attivit�[i].getScadenza().getTimeInMillis());
				fw.write(""+this.attivit�[i].getCompletamento().getTimeInMillis());
				fw.write(""+this.attivit�[i].getSvolgimento());					
				fw.write("");
			}
			this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione,true);
			return true;
		}
		
		return false;
	}
	
	//modifico l'attivit�, descrizione compresa
	public boolean aggiornaAttivit�(int indxAtt,String den,int svolg, GregorianCalendar data_Scad) throws IOException {
		this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione);
		//controllo che l'attivit� esista
		boolean ck=false;
		GregorianCalendar td = new GregorianCalendar();

		//controllo se esiste un attivit� sulla posizione indxAtt
		if(this.attivit�[indxAtt] != null) {
			this.attivit�[indxAtt].setSvolgimento(svolg,data_Scad);
			this.attivit�[indxAtt].setDescrizione(den);
			this.attivit�[indxAtt].setCompletamento(td);
			ck=true;
		}
		
		
		if(ck == true) {
			//riscrivo il file con le informazioni aggiornate
			for(int i=0;i<64;i++) {
				fw.write(this.attivit�[i].getDescrizione());
				fw.write(""+this.attivit�[i].getScadenza().getTimeInMillis());
				fw.write(""+this.attivit�[i].getCompletamento().getTimeInMillis());
				fw.write(""+this.attivit�[i].getSvolgimento());					
				fw.write("");
			}
			this.fw = new FileWriter(this.DIRECTORY_PROGETTI+this.denominazione,true);
			return true;
		}
		
		return false;
	}
	
	public int elencaAttivit�() {return this.num_attivit�;}
	public String elencaAttivit�Completate() {
		String attC="";
		for(int i=0;i<64;i++) {
			if(this.attivit�[i].getSvolgimento()==100) {
				attC+= this.attivit�[i].getDescrizione();
				attC+= this.attivit�[i].getScadenza();
				attC+= this.attivit�[i].getCompletamento();
				attC+= this.attivit�[i].getSvolgimento();
				attC+="";
			}
		}
		return attC;		
	}
	
	public String elencaAttivit�InScadenza() {
		String attScad="";
		GregorianCalendar td = new GregorianCalendar();
		long dtDiff;
		for(int i=0;i<64;i++) {
			//calcolo la differenza in millisecondi tra la data di scadenza dell'attivit� e oggi
			dtDiff= td.getTimeInMillis()-this.attivit�[i].getScadenza().getTimeInMillis();
			if(this.attivit�[i].getSvolgimento() < 100 && dtDiff < 0) {
				attScad+= this.attivit�[i].getDescrizione();
				attScad+= this.attivit�[i].getScadenza();
				attScad+= this.attivit�[i].getCompletamento();
				attScad+= this.attivit�[i].getSvolgimento();
				attScad+="";
			}
		}
		return attScad;
	}
	
	public String getProgetto() throws IOException{
		String pr="";
		
		do {
			if(br.readLine()!=null) {
			pr+=br.readLine();
			}
		}while (br.readLine() != null);
		return pr;
	}

}
