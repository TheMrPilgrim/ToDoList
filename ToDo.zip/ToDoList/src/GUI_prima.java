import java.awt.EventQueue;
import java.io.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.util.GregorianCalendar;


public class GUI_prima implements ActionListener{

	private JFrame frame;
	private final JPanel panel_1 = new JPanel();
	private JTextField txtAggAttivit;
	JPanel panel;
	JButton btnNewButton;		//crea progetto
	JButton btnNewButton_1;		//elenco progetti
	JComboBox comboBox;
	JButton btnNewButton_3;		//delete
	JPanel panel_2;
	JButton btnNewButton_5;		//chiudi progetto
	JButton btnNewButton_6;		//elenco att. compl
	JButton btnNewButton_7;		//elenco att. in scad
	JButton btnNewButton_8;		//crea attivit�
	JButton btnNewButton_10;	//elimina attivit�
	JButton btnNewButton_11;	//esporta

	Progetto p = null;			//progetto corrente
	ToDo current;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_prima window = new GUI_prima();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI_prima() throws IOException {
		// TODO Auto-generated method stub
		initialize();
		this.current = new ToDo();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 588, 460);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 578, 43);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		btnNewButton = new JButton("Crea Progetto");
		btnNewButton.setBounds(131, 11, 101, 23);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(this);
		
		btnNewButton_1 = new JButton("Elenco Progetti");
		btnNewButton_1.setBounds(337, 11, 105, 23);
		panel.add(btnNewButton_1);
		panel_1.setBounds(0, 42, 578, 78);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		btnNewButton_1.addActionListener(this);

		comboBox = new JComboBox();
		comboBox.setBounds(0, 0, 578, 20);
		panel_1.add(comboBox);
		comboBox.addActionListener(this);
		
		btnNewButton_3 = new JButton("DELETE");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_3.setBounds(0, 55, 568, 23);
		panel_1.add(btnNewButton_3);
		btnNewButton_3.addActionListener(this);

		panel_2 = new JPanel();
		panel_2.setBounds(0, 209, 578, 212);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		btnNewButton_5 = new JButton("Chiudi progetto");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_5.setBounds(0, 39, 142, 45);
		panel_2.add(btnNewButton_5);
		btnNewButton_5.addActionListener(this);

		btnNewButton_6 = new JButton("Elenco att. completate");
		btnNewButton_6.setBounds(0, 82, 142, 62);
		panel_2.add(btnNewButton_6);
		btnNewButton_6.addActionListener(this);
		
		btnNewButton_7 = new JButton("Ele. att. in scandenza");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_7.setBounds(0, 139, 142, 62);
		panel_2.add(btnNewButton_7);
		btnNewButton_7.addActionListener(this);
		
		btnNewButton_8 = new JButton("Crea attivit�");
		btnNewButton_8.setBounds(140, 0, 168, 40);
		panel_2.add(btnNewButton_8);
		btnNewButton_8.addActionListener(this);

		btnNewButton_10 = new JButton("Elimina attivit�");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_10.setBounds(308, 0, 174, 40);
		panel_2.add(btnNewButton_10);
		btnNewButton_10.addActionListener(this);
		
		btnNewButton_11 = new JButton("Esporta");
		btnNewButton_11.setBounds(473, 0, 105, 40);
		panel_2.add(btnNewButton_11);
		btnNewButton_11.addActionListener(this);
		
		txtAggAttivit = new JTextField();
		txtAggAttivit.setEditable(false);
		txtAggAttivit.setBounds(140, 39, 428, 151);
		panel_2.add(txtAggAttivit);
		txtAggAttivit.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(140, 39, 428, 45);
		panel_2.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(0, 123, 562, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(0, 143, 562, 55);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		textField_2.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			if(e.getSource() == "Crea Progetto") {
				this.textField_1.setText("Inserisci il nome del nuovo Progetto: ");
				this.p = new Progetto(getInput());
				this.current = new ToDo();
			} else if(e.getSource() == "Elenco Progetti") {
				this.textField.setText(this.current.elencaProgetti());
			}
			
			if(e.getSource() == "comboBox") {
				String s = this.current.getProgettoIndx(this.comboBox.getSelectedIndex());
				this.p = new Progetto(s);
				this.textField.setText(p.getProgetto());
			}
			
			if(e.getSource() == "EDIT") {
				
			}else if(e.getSource() == "DELETE" && this.p != null) {
				this.current.eliminaProgetto(this.p.getDenominazione());
				this.p=null;
			}
			
			if(e.getSource() == "Crea attivit�" && this.p !=null) {
				int y,m,d;
				this.textField_1.setText("Inserisci giorno/mese/anno di scadenza: ");
					String s = getInput();
					d=Integer.parseInt(getSingleValueFromIndx(0,1,s));
					m=Integer.parseInt(getSingleValueFromIndx(3,4,s));
					y=Integer.parseInt(getSingleValueFromIndx(6,9,s));
				this.textField_1.setText("");
				GregorianCalendar d_s = new GregorianCalendar(y,m,d);
					String des="";
				this.textField_1.setText("Inserisci la descrizione dell'attivit� da aggiungere: ");
					des=getInput();
				this.textField_1.setText("");
				p.creaAttivit�(des,d_s);
				this.textField.setText(p.getProgetto());
			} else if(e.getSource() == "Elimina attivit�" && this.p !=null) {
				String des="";
				this.textField_1.setText("Inserisci la descrizione dell'attivit� da eliminare: ");
					des=getInput();
				this.textField_1.setText("");
				p.eliminaAttivit�(des);
				this.textField.setText(p.getProgetto());
			}
			
			if(e.getSource() == "Esporta") {
				String dir = "";
				this.textField_1.setText("Inserisci la directory dove esportare: ");
					dir=getInput();
				this.textField_1.setText("");
				File f = new File("C:\\"+dir);
				f.getParentFile().mkdirs(); 
				f.createNewFile();
			}
			
			if(e.getSource() == "Chiudi Progetto") {
				this.textField.setText("");
				this.p = null;
			}
			
			if(e.getSource() == "Elenco att. completate" && this.p !=null) {
				this.textField.setText(this.p.elencaAttivit�Completate());
			} else if (e.getSource() == "Elenco att. in scandenza" && this.p !=null) {
				this.textField.setText(this.p.elencaAttivit�InScadenza());
			}
			
			}catch(IOException exp) {}
	}
	
	String getInput() {
		String inp="";
			inp = this.textField_2.getText();
		return inp;
	}
	String getSingleValueFromIndx(int indx1, int indx2, String s) {
		String ret="";
		for(int i = indx1; i<indx2; i++) {
			ret+=s.charAt(i);
		}
		return ret;
	}
}
