import java.awt.EventQueue;
import java.io.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.util.Scanner;

public class GUI implements ActionListener{

	private JFrame frame;
	private final JPanel panel_1 = new JPanel();
	private JTextField txtAggAttivit;
	private JTextField textField_1;
	private JTextField textField_2;
	JPanel panel;
	JButton btnNewButton;		//crea progetto
	JButton btnNewButton_1;		//elenco progetti
	JComboBox comboBox;
	JButton btnNewButton_2;		//edit
	JButton btnNewButton_3;		//delete
	JButton btnNewButton_4;		//back
	JPanel panel_2;
	JButton btnNewButton_5;		//chiudi progetto
	JButton btnNewButton_6;		//elenco att. compl
	JButton btnNewButton_7;		//elenco att. in scad
	JButton btnNewButton_8;		//crea attivit�
	JButton btnNewButton_9;		//agiungi attivit�
	JButton btnNewButton_10;	//elimina attivit�
	JButton btnNewButton_11;	//esporta

	Progetto p;			//progetto corrente
	ToDo current;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() throws IOException {
		// TODO Auto-generated method stub
		initialize();
		this.current = new ToDo();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 588, 344);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 578, 43);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		btnNewButton = new JButton("Crea Progetto");
		btnNewButton.setBounds(131, 11, 101, 23);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(this);
		
		btnNewButton_1 = new JButton("Elenco Progetti");
		btnNewButton_1.setBounds(337, 11, 105, 23);
		panel.add(btnNewButton_1);
		panel_1.setBounds(0, 42, 578, 78);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		btnNewButton_1.addActionListener(this);

		comboBox = new JComboBox();
		comboBox.setBounds(0, 0, 578, 20);
		panel_1.add(comboBox);
		comboBox.addActionListener(this);
		
		btnNewButton_2 = new JButton("EDIT");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_2.setBounds(0, 55, 196, 23);
		panel_1.add(btnNewButton_2);
		btnNewButton_2.addActionListener(this);
		
		btnNewButton_3 = new JButton("DELETE");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_3.setBounds(192, 55, 187, 23);
		panel_1.add(btnNewButton_3);
		btnNewButton_3.addActionListener(this);
		
		btnNewButton_4 = new JButton("BACK");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_4.setBounds(375, 55, 203, 23);
		panel_1.add(btnNewButton_4);
		btnNewButton_4.addActionListener(this);

		panel_2 = new JPanel();
		panel_2.setBounds(0, 117, 578, 212);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		btnNewButton_5 = new JButton("Chiudi progetto");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_5.setBounds(0, 39, 142, 45);
		panel_2.add(btnNewButton_5);
		btnNewButton_5.addActionListener(this);

		btnNewButton_6 = new JButton("Elenco att. completate");
		btnNewButton_6.setBounds(0, 82, 142, 62);
		panel_2.add(btnNewButton_6);
		btnNewButton_6.addActionListener(this);
		
		btnNewButton_7 = new JButton("Ele. att. in scandenza");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_7.setBounds(0, 139, 142, 62);
		panel_2.add(btnNewButton_7);
		btnNewButton_7.addActionListener(this);
		
		btnNewButton_8 = new JButton("Crea attivit�");
		btnNewButton_8.setBounds(140, 0, 120, 40);
		panel_2.add(btnNewButton_8);
		btnNewButton_8.addActionListener(this);
		
		btnNewButton_9 = new JButton("Aggiunta attivit�");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_9.setBounds(258, 0, 120, 40);
		panel_2.add(btnNewButton_9);
		btnNewButton_9.addActionListener(this);

		btnNewButton_10 = new JButton("Elimina attivit�");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_10.setBounds(376, 0, 106, 40);
		panel_2.add(btnNewButton_10);
		btnNewButton_10.addActionListener(this);
		
		btnNewButton_11 = new JButton("Esporta");
		btnNewButton_11.setBounds(473, 0, 105, 40);
		panel_2.add(btnNewButton_11);
		btnNewButton_11.addActionListener(this);
		
		txtAggAttivit = new JTextField();
		txtAggAttivit.setEditable(false);
		txtAggAttivit.setBounds(140, 39, 438, 45);
		panel_2.add(txtAggAttivit);
		txtAggAttivit.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(140, 82, 438, 62);
		panel_2.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setBounds(140, 139, 438, 62);
		panel_2.add(textField_2);
		textField_2.setColumns(10);
	}

	public void actionPerformed(ActionEvent e) {
		try {
		Scanner sc = new Scanner(System.in);
		if(e.getSource() == "Crea Progetto") {
			System.out.print("Inserisci il nome del file: ");
			this.p = new Progetto(sc.nextLine());
			this.textField
		} else if(e.getSource() == "Elenco Progetti") {
			
		}
		}catch(IOException exp) {}
	}

	
}
