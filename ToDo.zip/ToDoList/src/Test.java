import java.util.GregorianCalendar;
import java.io.*;

public class Test {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		GregorianCalendar td = new GregorianCalendar();
		FileWriter fw  = new FileWriter("./progetti/test.txt");
		
	
	}

}
