import java.util.GregorianCalendar;

public class Attivit� {
	
  String descrizione;
  GregorianCalendar scadenza;
  GregorianCalendar completamento;
  int svolgimento;
    
  public Attivit�() {
        this.descrizione = null;
        this.scadenza= new GregorianCalendar();
        this.completamento= new GregorianCalendar();
        this.svolgimento=0;       
    }
    
  public Attivit�(String descrizione,GregorianCalendar c) {
        this.descrizione =descrizione;
        this.scadenza= c;
        this.completamento= new GregorianCalendar();
        this.svolgimento=0;       
    }
  
  public Attivit�(Attivit� a) {
	  this.descrizione = a.getDescrizione();
	  this.scadenza= a.getScadenza();
	  this.svolgimento= a.getSvolgimento();
	  this.completamento = a.getCompletamento();			  
  }
    
  public String getDescrizione(){return descrizione;}    
  public GregorianCalendar getScadenza(){return scadenza;}    
  public GregorianCalendar getCompletamento(){return completamento;}    
  public int getSvolgimento(){return svolgimento;}
    
    
  public void setSvolgimento(int svolgimento,GregorianCalendar c){
    
    	if(svolgimento>=100) {
    		this.svolgimento=100;
    		this.completamento=c;
    	}else {
    		this.svolgimento=svolgimento;
        }
    }
  
  public void setScadenza(GregorianCalendar c){this.scadenza=c;}
  public void setCompletamento(GregorianCalendar c) {this.completamento=c;}
  public void setDescrizione(String d) {this.descrizione=d;}  
    

    
}