
import java.util.GregorianCalendar;
public class Attività
{
  String descrizione;
  GregorianCalendar scadenza;
  GregorianCalendar completamento;
  int svolgimento;
    public Attività()
    {
        this.descrizione = null;
        this.scadenza= new GregorianCalendar();
        this.completamento= new GregorianCalendar();
        this.svolgimento=0;
       
    }
    
    public Attività(String descrizione,GregorianCalendar c)
    {
        this.descrizione =descrizione;
        this.scadenza= c;
        this.completamento= new GregorianCalendar();
        this.svolgimento=0;
       
    }
    
    public String getDescrizione(){return descrizione;}
    
    public GregorianCalendar getScadenza(){return scadenza;}
    
    public GregorianCalendar getCompletamento(){return completamento;}
    
    public int getSvolgimento(){return svolgimento;}
    
    public void setSvolgimento(int svolgimento,GregorianCalendar c){
    
    if(svolgimento>=100)
    {
      this.svolgimento=100;
      this.completamento=c;
    }else
          this.svolgimento=svolgimento;
        }
        
   public void setScadenza(GregorianCalendar c){
          this.scadenza=c;
        }
    
    
    
    
    
    
    

    
    
    

    
}