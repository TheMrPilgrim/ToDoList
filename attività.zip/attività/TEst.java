

public class TEst
{
    public static void main(){
        Attività a = new Attività();
        
        System.out.println(a.getDescrizione());
        System.out.println(a.getScadenza().getTime());
        System.out.println(a.getCompletamento().getTime());
        System.out.println(a.getSvolgimento());
        
        
       

    }
    
    
}
